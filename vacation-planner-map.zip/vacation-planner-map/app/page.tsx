"use client"

import { useState } from "react"
import { MapContainer } from "@/components/map-container"
import { MapControls } from "@/components/map-controls"
import { locations } from "@/lib/locations-data"

export default function VacationPlannerPage() {
  const [selectedMonths, setSelectedMonths] = useState<Set<string>>(
    new Set(["June", "July", "August", "October", "November", "December"]),
  )
  const [selectedContinents, setSelectedContinents] = useState<Set<string>>(
    new Set(["North America", "South America", "Europe", "Asia", "Africa"]),
  )
  const [favorites, setFavorites] = useState<Set<number>>(new Set())
  const [visibleLocations, setVisibleLocations] = useState<Set<number>>(new Set(locations.map((_, i) => i)))
  const [sortMode, setSortMode] = useState<"itinerary" | "distance" | "name" | "continent">("itinerary")
  const [userPosition, setUserPosition] = useState<{ lat: number; lng: number } | null>(null)
  const [maxDistance, setMaxDistance] = useState<number>(Number.POSITIVE_INFINITY)
  const [showRoute, setShowRoute] = useState(false)
  const [onlyFavorites, setOnlyFavorites] = useState(false)

  return (
    <div className="h-screen flex bg-background">
      <MapControls
        selectedMonths={selectedMonths}
        setSelectedMonths={setSelectedMonths}
        selectedContinents={selectedContinents}
        setSelectedContinents={setSelectedContinents}
        favorites={favorites}
        setFavorites={setFavorites}
        visibleLocations={visibleLocations}
        setVisibleLocations={setVisibleLocations}
        sortMode={sortMode}
        setSortMode={setSortMode}
        userPosition={userPosition}
        setUserPosition={setUserPosition}
        maxDistance={maxDistance}
        setMaxDistance={setMaxDistance}
        showRoute={showRoute}
        setShowRoute={setShowRoute}
        onlyFavorites={onlyFavorites}
        setOnlyFavorites={setOnlyFavorites}
      />
      <div className="flex-1">
        <MapContainer
          selectedMonths={selectedMonths}
          selectedContinents={selectedContinents}
          favorites={favorites}
          setFavorites={setFavorites}
          visibleLocations={visibleLocations}
          setVisibleLocations={setVisibleLocations}
          sortMode={sortMode}
          userPosition={userPosition}
          maxDistance={maxDistance}
          showRoute={showRoute}
          onlyFavorites={onlyFavorites}
        />
      </div>
    </div>
  )
}
