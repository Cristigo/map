export interface SeasonalNote {
  emoji: string
  text: string
  level: "good" | "ok" | "warn"
}

export const seasonalNotes: Record<string, (month: string) => SeasonalNote> = {
  douala: () => ({ emoji: "🌧️", text: "Rainy season (Apr–Nov). Expect heavy showers & humidity.", level: "warn" }),
  bucharest: (m) =>
    ["June", "July", "August"].includes(m)
      ? { emoji: "🌤️", text: "Warm summer; occasional heat waves.", level: "ok" }
      : { emoji: "ℹ️", text: "Shoulder season.", level: "ok" },
  curitiba: () => ({ emoji: "🧥", text: "Southern Brazil winter (Jun–Aug): cool/chilly, some rain.", level: "ok" }),
  "st. john": () => ({ emoji: "🌫️", text: "Early summer but can be cool & foggy on the coast.", level: "ok" }),
  warsaw: () => ({ emoji: "🌤️", text: "Pleasant summer; possible hot spells.", level: "ok" }),
  stockholm: () => ({ emoji: "🌞", text: "Long days & mild summer.", level: "good" }),
  kaohsiung: (m) =>
    ["July", "August", "September", "October"].includes(m)
      ? { emoji: "🌀", text: "Hot/humid with typhoon risk (Jul–Oct).", level: "warn" }
      : { emoji: "ℹ️", text: "Humid subtropical.", level: "ok" },
  "panama city": (m) =>
    ["May", "June", "July", "August", "September", "October", "November"].includes(m)
      ? { emoji: "🌧️", text: "Rainy season; daily downpours, very humid.", level: "warn" }
      : { emoji: "🌤️", text: "Drier season.", level: "good" },
  porto: () => ({ emoji: "🌤️", text: "Dry warm summer; breezy.", level: "good" }),
  calgary: () => ({ emoji: "🔥", text: "Summer; occasional heat & wildfire smoke possible.", level: "ok" }),
  quito: () => ({ emoji: "⛰️", text: "Cool, often-dry Aug; strong sun at altitude.", level: "ok" }),
  vilnius: () => ({ emoji: "🌤️", text: "Mild summer; occasional showers.", level: "ok" }),
  hamburg: () => ({ emoji: "🌦️", text: "Warmish; passing showers & wind possible.", level: "ok" }),
  utrecht: () => ({ emoji: "🌦️", text: "Mild summer; chance of rain.", level: "ok" }),
  johannesburg: () => ({ emoji: "🧥", text: "Late winter dry & sunny; chilly nights.", level: "ok" }),
  milwaukee: () => ({ emoji: "⛈️", text: "Warm/ humid late-Aug; thunderstorms possible.", level: "ok" }),
  manila: (m) =>
    ["May", "June", "July", "August", "September", "October", "November"].includes(m)
      ? { emoji: "🌀", text: "Rainy/typhoon season (Jun–Nov).", level: "warn" }
      : { emoji: "🌤️", text: "Dry season.", level: "good" },
  "san diego": () => ({ emoji: "🌤️", text: "Mild & dry; chance of Santa Ana winds.", level: "good" }),
  bangkok: (m) =>
    ["November", "December", "January", "February"].includes(m)
      ? { emoji: "🌞", text: "Cool/dry peak season — best weather.", level: "good" }
      : ["May", "June", "July", "August", "September", "October"].includes(m)
        ? { emoji: "🌧️", text: "Rainy season with downpours (May–Oct).", level: "warn" }
        : { emoji: "ℹ️", text: "Hot shoulder season.", level: "ok" },
}

export function getSeasonalNote(locationName: string, month: string): SeasonalNote {
  const key = Object.keys(seasonalNotes).find((k) => locationName.toLowerCase().includes(k))
  return key ? seasonalNotes[key](month) : { emoji: "ℹ️", text: "Seasonal info varies.", level: "ok" }
}
