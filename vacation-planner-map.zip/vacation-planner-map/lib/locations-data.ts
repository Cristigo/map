export interface Location {
  name: string
  lat: number
  lng: number
  continent: string
  dates: string
  month: string
  order: number
}

export const locations: Location[] = [
  {
    name: "Douala, Cameroon",
    lat: 4.0511,
    lng: 9.7679,
    continent: "Africa",
    dates: "June 19–21",
    month: "June",
    order: 1,
  },
  {
    name: "Bucharest, Romania",
    lat: 44.4268,
    lng: 26.1025,
    continent: "Europe",
    dates: "June 19–21",
    month: "June",
    order: 2,
  },
  {
    name: "Curitiba, Brazil",
    lat: -25.4284,
    lng: -49.2733,
    continent: "South America",
    dates: "June 26–28",
    month: "June",
    order: 3,
  },
  {
    name: "St. John's, NL, Canada",
    lat: 47.5615,
    lng: -52.7126,
    continent: "North America",
    dates: "July 3–5",
    month: "July",
    order: 4,
  },
  {
    name: "Warsaw, Poland",
    lat: 52.2297,
    lng: 21.0122,
    continent: "Europe",
    dates: "July 3–5",
    month: "July",
    order: 5,
  },
  {
    name: "Stockholm, Sweden",
    lat: 59.3293,
    lng: 18.0686,
    continent: "Europe",
    dates: "July 3–5",
    month: "July",
    order: 6,
  },
  {
    name: "Kaohsiung, Taiwan",
    lat: 22.6273,
    lng: 120.3014,
    continent: "Asia",
    dates: "July 3–5",
    month: "July",
    order: 7,
  },
  {
    name: "Panama City, Panama",
    lat: 8.9824,
    lng: -79.5199,
    continent: "North America",
    dates: "July 10–12",
    month: "July",
    order: 8,
  },
  {
    name: "Porto, Portugal",
    lat: 41.1579,
    lng: -8.6291,
    continent: "Europe",
    dates: "July 10–12",
    month: "July",
    order: 9,
  },
  {
    name: "Calgary, AB, Canada",
    lat: 51.0447,
    lng: -114.0719,
    continent: "North America",
    dates: "July 31–Aug 2",
    month: "July",
    order: 10,
  },
  {
    name: "Quito, Ecuador",
    lat: -0.1807,
    lng: -78.4678,
    continent: "South America",
    dates: "Aug 7–9",
    month: "August",
    order: 11,
  },
  {
    name: "Vilnius, Lithuania",
    lat: 54.6872,
    lng: 25.2797,
    continent: "Europe",
    dates: "Aug 7–9",
    month: "August",
    order: 12,
  },
  {
    name: "Hamburg, Germany",
    lat: 53.5511,
    lng: 9.9937,
    continent: "Europe",
    dates: "Aug 14–16",
    month: "August",
    order: 13,
  },
  {
    name: "Utrecht, Netherlands",
    lat: 52.0907,
    lng: 5.1214,
    continent: "Europe",
    dates: "Aug 14–16",
    month: "August",
    order: 14,
  },
  {
    name: "Johannesburg, South Africa",
    lat: -26.2041,
    lng: 28.0473,
    continent: "Africa",
    dates: "Aug 28–30",
    month: "August",
    order: 15,
  },
  {
    name: "Milwaukee, USA",
    lat: 43.042,
    lng: -87.9096,
    continent: "North America",
    dates: "Aug 28–30",
    month: "August",
    order: 16,
  },
  {
    name: "Manila, Philippines",
    lat: 14.5995,
    lng: 120.9842,
    continent: "Asia",
    dates: "Oct 30–Nov 1",
    month: "October",
    order: 17,
  },
  {
    name: "San Diego, USA",
    lat: 32.7157,
    lng: -117.161,
    continent: "North America",
    dates: "Nov 27–29",
    month: "November",
    order: 18,
  },
  {
    name: "Bangkok, Thailand",
    lat: 13.7563,
    lng: 100.5018,
    continent: "Asia",
    dates: "Dec 11–13",
    month: "December",
    order: 19,
  },
]

export const monthOrder = ["June", "July", "August", "October", "November", "December"]

export const quarterMonths = {
  Q2: ["April", "May", "June"],
  Q3: ["July", "August", "September"],
  Q4: ["October", "November", "December"],
}

export const continentColors = {
  "North America": "#2E7BEA", // blue
  "South America": "#41A85F", // green
  Europe: "#D64541", // red
  Asia: "#F39C12", // orange
  Africa: "#8E44AD", // violet
}

export const markerIcons = {
  "North America": "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-blue.png",
  "South America": "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-green.png",
  Europe: "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png",
  Asia: "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-orange.png",
  Africa: "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-violet.png",
}

export const shadowIcon = "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png"
