"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Star, MapPin, Filter, Calculator } from "lucide-react"
import { locations, monthOrder, quarterMonths, continentColors } from "@/lib/locations-data"
import { kmBetween, formatDistance } from "@/lib/utils"

interface MapControlsProps {
  selectedMonths: Set<string>
  setSelectedMonths: (months: Set<string>) => void
  selectedContinents: Set<string>
  setSelectedContinents: (continents: Set<string>) => void
  favorites: Set<number>
  setFavorites: (favorites: Set<number>) => void
  visibleLocations: Set<number>
  setVisibleLocations: (visible: Set<number>) => void
  sortMode: "itinerary" | "distance" | "name" | "continent"
  setSortMode: (mode: "itinerary" | "distance" | "name" | "continent") => void
  userPosition: { lat: number; lng: number } | null
  setUserPosition: (pos: { lat: number; lng: number } | null) => void
  maxDistance: number
  setMaxDistance: (distance: number) => void
  showRoute: boolean
  setShowRoute: (show: boolean) => void
  onlyFavorites: boolean
  setOnlyFavorites: (only: boolean) => void
}

export function MapControls({
  selectedMonths,
  setSelectedMonths,
  selectedContinents,
  setSelectedContinents,
  favorites,
  setFavorites,
  visibleLocations,
  setVisibleLocations,
  sortMode,
  setSortMode,
  userPosition,
  setUserPosition,
  maxDistance,
  setMaxDistance,
  showRoute,
  setShowRoute,
  onlyFavorites,
  setOnlyFavorites,
}: MapControlsProps) {
  const [showLegendIcons, setShowLegendIcons] = useState(false)
  const [tripSpeed, setTripSpeed] = useState(800)
  const [layoverTime, setLayoverTime] = useState(2.5)

  const continents = ["North America", "South America", "Europe", "Asia", "Africa"]

  const handleMonthToggle = (month: string, checked: boolean) => {
    const newMonths = new Set(selectedMonths)
    if (checked) {
      newMonths.add(month)
    } else {
      newMonths.delete(month)
    }
    setSelectedMonths(newMonths)
  }

  const handleContinentToggle = (continent: string, checked: boolean) => {
    const newContinents = new Set(selectedContinents)
    if (checked) {
      newContinents.add(continent)
    } else {
      newContinents.delete(continent)
    }
    setSelectedContinents(newContinents)
  }

  const handleLocationToggle = (index: number, checked: boolean) => {
    const newVisible = new Set(visibleLocations)
    if (checked) {
      newVisible.add(index)
    } else {
      newVisible.delete(index)
    }
    setVisibleLocations(newVisible)
  }

  const toggleFavorite = (index: number) => {
    const newFavorites = new Set(favorites)
    if (newFavorites.has(index)) {
      newFavorites.delete(index)
    } else {
      newFavorites.add(index)
    }
    setFavorites(newFavorites)
  }

  const handleGetLocation = () => {
    if (!navigator.geolocation) {
      alert("Geolocation not supported.")
      return
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserPosition({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
        })
        setMaxDistance(20000)
      },
      (err) => alert("Could not get your location: " + err.message),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 600000 },
    )
  }

  const getSortedLocations = () => {
    const indices = Array.from({ length: locations.length }, (_, i) => i)
    return indices.sort((i, j) => {
      if (sortMode === "distance" && userPosition) {
        return kmBetween(userPosition, locations[i]) - kmBetween(userPosition, locations[j])
      }
      if (sortMode === "name") {
        return locations[i].name.localeCompare(locations[j].name)
      }
      if (sortMode === "continent") {
        return (
          locations[i].continent.localeCompare(locations[j].continent) ||
          locations[i].name.localeCompare(locations[j].name)
        )
      }
      return locations[i].order - locations[j].order
    })
  }

  const calculateTrip = (locationIndices: number[]) => {
    if (locationIndices.length < 2) return { legs: 0, distance: 0, flightTime: 0, layoverTime: 0 }

    let totalDistance = 0
    for (let i = 1; i < locationIndices.length; i++) {
      totalDistance += kmBetween(locations[locationIndices[i - 1]], locations[locationIndices[i]])
    }

    const flightTime = totalDistance / tripSpeed
    const totalLayoverTime = layoverTime * (locationIndices.length - 1)

    return {
      legs: locationIndices.length - 1,
      distance: totalDistance,
      flightTime,
      layoverTime: totalLayoverTime,
    }
  }

  const visibleFavorites = Array.from(favorites).filter((i) => {
    const location = locations[i]
    return (
      selectedMonths.has(location.month) &&
      selectedContinents.has(location.continent) &&
      visibleLocations.has(i) &&
      (!userPosition || !isFinite(maxDistance) || kmBetween(userPosition, location) <= maxDistance)
    )
  })

  const tripStats = calculateTrip(getSortedLocations().filter((i) => visibleFavorites.includes(i)))

  return (
    <div className="w-80 h-full bg-sidebar border-r border-sidebar-border overflow-y-auto">
      <div className="p-4 space-y-4">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground">Vacation Planner</h1>
          <p className="text-sm text-muted-foreground">Plan your perfect trip</p>
        </div>

        {/* Legend */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm">Legend</CardTitle>
              <div className="flex items-center space-x-2">
                <Checkbox id="legend-icons" checked={showLegendIcons} onCheckedChange={setShowLegendIcons} />
                <Label htmlFor="legend-icons" className="text-xs">
                  Icons
                </Label>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            {continents.map((continent) => (
              <div key={continent} className="flex items-center gap-2">
                {showLegendIcons ? (
                  <img
                    src={`https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-${continent === "North America" ? "blue" : continent === "South America" ? "green" : continent === "Europe" ? "red" : continent === "Asia" ? "orange" : "violet"}.png`}
                    alt={continent}
                    className="w-4 h-6"
                  />
                ) : (
                  <div
                    className="w-4 h-4 rounded border"
                    style={{ backgroundColor: continentColors[continent as keyof typeof continentColors] }}
                  />
                )}
                <span className="text-sm">{continent}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Month Filter */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Filter className="w-4 h-4" />
              Months
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-2">
              {monthOrder.map((month) => (
                <div key={month} className="flex items-center space-x-2">
                  <Checkbox
                    id={`month-${month}`}
                    checked={selectedMonths.has(month)}
                    onCheckedChange={(checked) => handleMonthToggle(month, checked as boolean)}
                  />
                  <Label htmlFor={`month-${month}`} className="text-xs">
                    {month}
                  </Label>
                </div>
              ))}
            </div>
            <div className="flex gap-2 flex-wrap">
              <Button size="sm" variant="outline" onClick={() => setSelectedMonths(new Set(monthOrder))}>
                All
              </Button>
              <Button size="sm" variant="outline" onClick={() => setSelectedMonths(new Set())}>
                None
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setSelectedMonths(new Set(quarterMonths.Q2.filter((m) => monthOrder.includes(m))))}
              >
                Q2
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setSelectedMonths(new Set(quarterMonths.Q3.filter((m) => monthOrder.includes(m))))}
              >
                Q3
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setSelectedMonths(new Set(quarterMonths.Q4.filter((m) => monthOrder.includes(m))))}
              >
                Q4
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Continent Filter */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Continents</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-2">
              {continents.map((continent) => (
                <div key={continent} className="flex items-center space-x-2">
                  <Checkbox
                    id={`continent-${continent}`}
                    checked={selectedContinents.has(continent)}
                    onCheckedChange={(checked) => handleContinentToggle(continent, checked as boolean)}
                  />
                  <Label htmlFor={`continent-${continent}`} className="text-xs">
                    {continent}
                  </Label>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={() => setSelectedContinents(new Set(continents))}>
                All
              </Button>
              <Button size="sm" variant="outline" onClick={() => setSelectedContinents(new Set())}>
                None
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Location Controls */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              Locations
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex gap-2 flex-wrap">
              <Button
                size="sm"
                variant="outline"
                onClick={() => setVisibleLocations(new Set(Array.from({ length: locations.length }, (_, i) => i)))}
              >
                Show All
              </Button>
              <Button size="sm" variant="outline" onClick={() => setVisibleLocations(new Set())}>
                Hide All
              </Button>
              <Button size="sm" variant="outline" onClick={handleGetLocation}>
                📍 My Location
              </Button>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Label htmlFor="sort-mode" className="text-xs">
                  Sort:
                </Label>
                <Select value={sortMode} onValueChange={(value: any) => setSortMode(value)}>
                  <SelectTrigger className="h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="itinerary">Itinerary</SelectItem>
                    <SelectItem value="distance">Distance</SelectItem>
                    <SelectItem value="name">Name</SelectItem>
                    <SelectItem value="continent">Continent</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox id="show-route" checked={showRoute} onCheckedChange={setShowRoute} />
                <Label htmlFor="show-route" className="text-xs">
                  Show route
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox id="only-favorites" checked={onlyFavorites} onCheckedChange={setOnlyFavorites} />
                <Label htmlFor="only-favorites" className="text-xs">
                  Only favorites
                </Label>
              </div>

              {userPosition && (
                <div className="space-y-2">
                  <Label className="text-xs">
                    Max distance: {isFinite(maxDistance) ? formatDistance(maxDistance) : "∞"}
                  </Label>
                  <Slider
                    value={[isFinite(maxDistance) ? maxDistance : 20000]}
                    onValueChange={([value]) => setMaxDistance(value)}
                    max={20000}
                    min={200}
                    step={100}
                    className="w-full"
                  />
                </div>
              )}
            </div>

            <ScrollArea className="h-48">
              <div className="space-y-1">
                {getSortedLocations().map((index) => {
                  const location = locations[index]
                  const isVisible = selectedMonths.has(location.month) && selectedContinents.has(location.continent)
                  return (
                    <div
                      key={index}
                      className={`flex items-center gap-2 p-2 rounded ${!isVisible ? "opacity-40" : ""}`}
                    >
                      <Checkbox
                        checked={visibleLocations.has(index)}
                        onCheckedChange={(checked) => handleLocationToggle(index, checked as boolean)}
                        disabled={!isVisible}
                      />
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-medium truncate">{location.name}</div>
                        <div className="text-xs text-muted-foreground">{location.dates}</div>
                        {userPosition && (
                          <Badge variant="outline" className="text-xs">
                            {formatDistance(kmBetween(userPosition, location))}
                          </Badge>
                        )}
                      </div>
                      <Button size="sm" variant="ghost" className="p-1 h-auto" onClick={() => toggleFavorite(index)}>
                        <Star className={`w-4 h-4 ${favorites.has(index) ? "fill-yellow-400 text-yellow-400" : ""}`} />
                      </Button>
                    </div>
                  )
                })}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Trip Estimator */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Calculator className="w-4 h-4" />
              Trip Estimator
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="speed" className="text-xs">
                  Speed (km/h)
                </Label>
                <Input
                  id="speed"
                  type="number"
                  value={tripSpeed}
                  onChange={(e) => setTripSpeed(Number(e.target.value))}
                  min={400}
                  max={1000}
                  className="h-8"
                />
              </div>
              <div>
                <Label htmlFor="layover" className="text-xs">
                  Layover (h)
                </Label>
                <Input
                  id="layover"
                  type="number"
                  value={layoverTime}
                  onChange={(e) => setLayoverTime(Number(e.target.value))}
                  min={0}
                  max={6}
                  step={0.5}
                  className="h-8"
                />
              </div>
            </div>

            <div className="text-xs space-y-1">
              <div>
                <strong>Legs:</strong> {tripStats.legs} • <strong>Distance:</strong>{" "}
                {formatDistance(tripStats.distance)}
              </div>
              <div>
                <strong>Flight time:</strong> {tripStats.flightTime.toFixed(1)}h • <strong>Layovers:</strong>{" "}
                {tripStats.layoverTime.toFixed(1)}h
              </div>
              <div>
                <strong>Total:</strong> {(tripStats.flightTime + tripStats.layoverTime).toFixed(1)}h{" "}
                <span className="text-muted-foreground">
                  (≈ {((tripStats.flightTime + tripStats.layoverTime) / 24).toFixed(1)} days)
                </span>
              </div>
            </div>

            <p className="text-xs text-muted-foreground">Tip: ⭐ favorite places to calculate trip estimates</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
