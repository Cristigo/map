"use client"

import { useEffect, useRef } from "react"
import { locations, markerIcons, shadowIcon } from "@/lib/locations-data"
import { getSeasonalNote } from "@/lib/seasonal-data"
import { kmBetween, formatDistance } from "@/lib/utils"

interface MapContainerProps {
  selectedMonths: Set<string>
  selectedContinents: Set<string>
  favorites: Set<number>
  setFavorites: (favorites: Set<number>) => void
  visibleLocations: Set<number>
  setVisibleLocations: (visible: Set<number>) => void
  sortMode: "itinerary" | "distance" | "name" | "continent"
  userPosition: { lat: number; lng: number } | null
  maxDistance: number
  showRoute: boolean
  onlyFavorites: boolean
}

export function MapContainer({
  selectedMonths,
  selectedContinents,
  favorites,
  setFavorites,
  visibleLocations,
  setVisibleLocations,
  sortMode,
  userPosition,
  maxDistance,
  showRoute,
  onlyFavorites,
}: MapContainerProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<any>(null)
  const markersRef = useRef<Map<number, any>>(new Map())
  const routeLineRef = useRef<any>(null)

  useEffect(() => {
    if (typeof window === "undefined") return

    const initMap = async () => {
      // Dynamically import Leaflet to avoid SSR issues
      const L = (await import("leaflet")).default

      // Fix for default markers
      delete (L.Icon.Default.prototype as any)._getIconUrl
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
        iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
        shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
      })

      if (!mapRef.current || mapInstanceRef.current) return

      // Initialize map
      const map = L.map(mapRef.current, { worldCopyJump: true })
      mapInstanceRef.current = map

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      }).addTo(map)

      // Create markers
      const bounds = L.latLngBounds([])
      locations.forEach((location, index) => {
        const icon = L.icon({
          iconUrl: markerIcons[location.continent as keyof typeof markerIcons],
          shadowUrl: shadowIcon,
          iconSize: [25, 41],
          iconAnchor: [12, 41],
        })

        const marker = L.marker([location.lat, location.lng], { icon })
        markersRef.current.set(index, marker)

        // Create popup content
        const seasonalNote = getSeasonalNote(location.name, location.month)
        const distanceText = userPosition
          ? `<br><span class="text-sm text-muted-foreground">Distance: ${formatDistance(kmBetween(userPosition, location))}</span>`
          : ""

        marker.bindPopup(`
          <div class="p-2">
            <div class="font-semibold">${location.name}</div>
            <div class="text-sm text-muted-foreground">${location.continent}</div>
            <div class="text-sm">Dates: ${location.dates}</div>
            ${distanceText}
            <div class="text-sm mt-1">${seasonalNote.emoji} ${seasonalNote.text}</div>
          </div>
        `)

        marker.addTo(map)
        bounds.extend([location.lat, location.lng])
      })

      map.fitBounds(bounds.pad(0.2))
    }

    initMap()

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove()
        mapInstanceRef.current = null
      }
    }
  }, [])

  // Update visibility and route
  useEffect(() => {
    if (!mapInstanceRef.current) return

    const visible = new Set<number>()

    locations.forEach((location, index) => {
      const marker = markersRef.current.get(index)
      if (!marker) return

      const monthOk = selectedMonths.has(location.month)
      const continentOk = selectedContinents.has(location.continent)
      const visibleOk = visibleLocations.has(index)
      const favoriteOk = !onlyFavorites || favorites.has(index)
      const distanceOk = !userPosition || !isFinite(maxDistance) || kmBetween(userPosition, location) <= maxDistance

      const shouldShow = monthOk && continentOk && visibleOk && favoriteOk && distanceOk

      if (shouldShow) {
        marker.addTo(mapInstanceRef.current)
        visible.add(index)
      } else {
        marker.remove()
      }
    })

    // Update route line
    if (routeLineRef.current) {
      routeLineRef.current.remove()
      routeLineRef.current = null
    }

    if (showRoute && visible.size >= 2) {
      const L = require("leaflet")
      const visibleArray = Array.from(visible)

      // Sort according to current sort mode
      visibleArray.sort((i, j) => {
        if (sortMode === "distance" && userPosition) {
          return kmBetween(userPosition, locations[i]) - kmBetween(userPosition, locations[j])
        }
        if (sortMode === "name") {
          return locations[i].name.localeCompare(locations[j].name)
        }
        if (sortMode === "continent") {
          return (
            locations[i].continent.localeCompare(locations[j].continent) ||
            locations[i].name.localeCompare(locations[j].name)
          )
        }
        return locations[i].order - locations[j].order
      })

      const points = visibleArray.map((i) => [locations[i].lat, locations[i].lng])
      routeLineRef.current = L.polyline(points, {
        weight: 3,
        opacity: 0.7,
        color: "#0891b2", // Primary color
      }).addTo(mapInstanceRef.current)
    }
  }, [
    selectedMonths,
    selectedContinents,
    visibleLocations,
    favorites,
    onlyFavorites,
    userPosition,
    maxDistance,
    showRoute,
    sortMode,
  ])

  return (
    <div className="relative h-full w-full">
      <div ref={mapRef} className="h-full w-full" />

      {/* Load Leaflet CSS */}
      <link
        rel="stylesheet"
        href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
        integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
        crossOrigin=""
      />
    </div>
  )
}
